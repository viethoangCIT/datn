package com.example.viethoang.apphostelgooglemaps;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class AddActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleApiClient.OnConnectionFailedListener{



    private GoogleMap mMap;
    private static final String TAG = "AddActivity";
    private static final float DEFAULT_ZOOM = 13f;
    private static final LatLngBounds LAT_LNG_BOUNDS = new LatLngBounds(new LatLng(-40, -168), new LatLng(71, 136));
    private GoogleApiClient mGoogleApiClient;

    private Geocoder geocoder;
    private List<Address> addresses;


    private double mlat = 0;
    private double mlong = 0;
    private String mAddress = "";

    private Button btnDangTin, btnChonAnh;
    private EditText txtGiaPhong, txtDienTich, txtDienThoai, txtInfo, txtUsername;
    private ImageView imgPicture, imgChonAnh;

    private DatabaseReference mDatabase;

    private static int RESULT_LOAD_IMAGE = 1;

    private Uri imageUri;

    FirebaseStorage firebaseStorage ;
    StorageReference storageReference;
    public String s_url  = "";

    @SuppressLint("WrongViewCast")
    private void anhXa()
    {
        btnDangTin = (Button) findViewById(R.id.btnDangTin);
        txtGiaPhong = (EditText)findViewById(R.id.txtGiaPhong);
        txtDienTich = (EditText)findViewById(R.id.txtDienTich);
        txtDienThoai = (EditText)findViewById(R.id.txtDienThoai);
        txtInfo = (EditText) findViewById(R.id.txt_information);

        txtUsername = (EditText) findViewById(R.id.txtUsername);

        imgPicture = (ImageView)findViewById(R.id.imgpicture);
        imgChonAnh = (ImageView)findViewById(R.id.imgChonAnh);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReference();



        anhXa();

        initMap();
        saveDangtin();
    }

    private void upLoadFile()
    {
        if((mlat != 0 && mlong != 0) && !txtGiaPhong.getText().toString().trim().equals("")) {
            if (imageUri != null) {
                StorageReference ref = storageReference.child("Place/" + UUID.randomUUID().toString());
                ref.putFile(imageUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                Uri downloadUrl = taskSnapshot.getDownloadUrl();

                                s_url = String.valueOf(downloadUrl);
                                    mDatabase = FirebaseDatabase.getInstance().getReference();


                                    String keyID = FirebaseDatabase.getInstance().getReference().child("Place").push().getKey();
                                    String hoten = txtUsername.getText().toString().trim();
                                    String toaDo = String.valueOf(mlat) + "," + String.valueOf(mlong);
                                    String giaPhong = txtGiaPhong.getText().toString().trim();
                                    String dienTich = txtDienTich.getText().toString().trim();
                                    String dienThoai = txtDienThoai.getText().toString().trim();
                                    String info = txtInfo.getText().toString().trim();
                                    String title = s_url;

                                    Calendar c = Calendar.getInstance();
                                    SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                                    String formatdate = df.format(c.getTime());

                                    Place place = new Place(keyID, hoten, toaDo,mAddress, giaPhong, dienTich, dienThoai, info, title,formatdate);
                                    mDatabase.child("Place").push().setValue(place);

                                    Toast.makeText(AddActivity.this, "Đăng tin thành công", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(AddActivity.this, HomeActivity.class);
                                    startActivity(intent);
                                    finish();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                            }
                        });

            }
            else
            {
                Toast.makeText(AddActivity.this, "Chọn ảnh", Toast.LENGTH_SHORT).show();
            }
        }
        if (txtGiaPhong.getText().toString().trim().equals("")) {
            Toast.makeText(AddActivity.this, "Nhập giá phòng trọ", Toast.LENGTH_SHORT).show();
            txtGiaPhong.requestFocus();
        }
        if(mlat == 0 && mlong == 0){
            Toast.makeText(AddActivity.this, "Xin mời chọn toạ độ", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveDangtin()
    {

        imgChonAnh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                startActivityForResult(intent,RESULT_LOAD_IMAGE);
            }
        });


        btnDangTin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                upLoadFile();


            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            try {
                imageUri = data.getData();
                final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                imgPicture.setImageBitmap(selectedImage);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }else {
            Toast.makeText(AddActivity.this, "You haven't picked Image",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }


    private void initMap(){
        Log.d(TAG, "initMap: initalizing map");
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapAdd);
        mapFragment.getMapAsync(AddActivity.this);

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
//        Toast.makeText(this, "Map is Ready", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onMapReady: map is ready");

        mMap = googleMap;
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(16.0471659,108.1716864),DEFAULT_ZOOM));
        init();

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {

                mlat = latLng.latitude;
                mlong = latLng.longitude;
                drawMarker(new LatLng(mlat,mlong));

                geocoder = new Geocoder(AddActivity.this, Locale.getDefault());

                try {
                    addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude,1);
                    String address = addresses.get(0).getAddressLine(0);
                    String city = addresses.get(0).getLocality();
                    String state = addresses.get(0).getAdminArea();
                    String conutry = addresses.get(0).getCountryName();
                    String postalCode = addresses.get(0).getPostalCode();
                    String knowName = addresses.get(0).getFeatureName();

                    mAddress = address;
                    Toast.makeText(AddActivity.this, ""+mAddress, Toast.LENGTH_LONG).show();
//                    Toast.makeText(AddActivity.this, "address: "+address + ". City: "+city+". state: "+state+". country: "+conutry+". postal: "+postalCode+". know: "+ knowName, Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void init() {
        Log.d(TAG, "init: initializing");

        mGoogleApiClient = new GoogleApiClient
                .Builder(this)
                .addApi(Places.GEO_DATA_API)
                .addApi(Places.PLACE_DETECTION_API)
                .enableAutoManage(this, this)
                .build();
    }

    private void drawMarker(LatLng point) {
        // Creating an instance of MarkerOptions
        mMap.clear();
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(point);
        mMap.addMarker(markerOptions);
    }
}
