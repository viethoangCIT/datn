package com.example.viethoang.apphostelgooglemaps;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Detail extends AppCompatActivity implements OnMapReadyCallback, GoogleApiClient.OnConnectionFailedListener{

    private String id_place = "";

    ImageView imgHinh;
    TextView txtGiaPhong, txtDienTich, txtDienThoai, txtDiaChi, txtMota;


    private void anhXa()
    {
        imgHinh = (ImageView) findViewById(R.id.imgDetailHinh);
        txtGiaPhong = (TextView)findViewById(R.id.txtDetailGiaPhong);
        txtDienTich = (TextView)findViewById(R.id.txtDetailDienTich);
        txtDienThoai = (TextView)findViewById(R.id.txtDetaiDienThoai);
        txtDiaChi = (TextView)findViewById(R.id.txtDetailDiaChi);
        txtMota = (TextView)findViewById(R.id.txtDetailMoTa);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_detail);
        anhXa();

        Bundle bundle = getIntent().getExtras();
        if(bundle != null)
        {
            id_place = bundle.getString("id_place");
        }
        initMap();

        Query all = FirebaseDatabase.getInstance().getReference("Place").orderByChild("id_place").equalTo(id_place);
        all.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                placeArrayList = new ArrayList<>();
                for(DataSnapshot item : dataSnapshot.getChildren())
                {
                    Place place = item.getValue(Place.class);
                    placeArrayList.add(place);
                }

                if(placeArrayList!=null)
                {
//                    Toast.makeText(MapActivity.this, "mang k null", Toast.LENGTH_SHORT).show();
                    for(int i = 0; i < placeArrayList.size(); i++)
                    {
                        try {
                            String lnglat = placeArrayList.get(i).getLnglat().toString().trim();


                            Picasso.with(Detail.this).load(placeArrayList.get(i).getTitle().toString().trim()).into(imgHinh);
                            txtGiaPhong.setText(placeArrayList.get(i).getGiaPhong().toString().trim());
                            txtDienTich.setText(placeArrayList.get(i).getDienTich().toString().trim());
                            txtDienThoai.setText(placeArrayList.get(i).getDienThoai().toString().trim());
                            txtDiaChi.setText(placeArrayList.get(i).getDiaChi().toString().trim());
                            txtMota.setText(placeArrayList.get(i).getInfo().toString().trim());

                            String[] sLnglat = lnglat.split(",");
                            String sLnglat_01 = sLnglat[0].toString().trim();
                            String sLnglat_02 = sLnglat[1].toString().trim();


                            mlat = Double.parseDouble(sLnglat_01);
                            mlong = Double.parseDouble(sLnglat_02);
                            //end: cat chuoi sau do chuyen thanh double
                            if(mlat != 0 && mlong != 0)
                            {
                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(mlat,mlong),DEFAULT_ZOOM));
                                mMap.addMarker(new MarkerOptions().position(new LatLng(mlat,mlong)));
                            }
                            }

                        catch (NullPointerException e)
                        {
                            Log.d(TAG,"exception: "+e.getMessage());
                        }

                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(Detail.this, "Có lỗi xảy ra", Toast.LENGTH_SHORT).show();
            }
        });

    }


    private ArrayList<Place> placeArrayList = null;

    private GoogleMap mMap;
    private static final String TAG = "AddActivity";
    private static final float DEFAULT_ZOOM = 13f;
    private static final LatLngBounds LAT_LNG_BOUNDS = new LatLngBounds(new LatLng(-40, -168), new LatLng(71, 136));
    private GoogleApiClient mGoogleApiClient;

    private Geocoder geocoder;

    private double mlat = 0;
    private double mlong = 0;

    private DatabaseReference mDatabase;


    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }


    private void initMap(){
        Log.d(TAG, "initMap: initalizing map");
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapDetail);
        mapFragment.getMapAsync(Detail.this);

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
//        Toast.makeText(this, "Map is Ready", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onMapReady: map is ready");

        mMap = googleMap;
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(16.0471659,108.1716864),DEFAULT_ZOOM));
        init();

    }

    private void init() {
        Log.d(TAG, "init: initializing");

        mGoogleApiClient = new GoogleApiClient
                .Builder(this)
                .addApi(Places.GEO_DATA_API)
                .addApi(Places.PLACE_DETECTION_API)
                .enableAutoManage(this, this)
                .build();
    }

    private void drawMarker(LatLng point) {
        // Creating an instance of MarkerOptions
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(point);
        mMap.addMarker(markerOptions);
    }
}
