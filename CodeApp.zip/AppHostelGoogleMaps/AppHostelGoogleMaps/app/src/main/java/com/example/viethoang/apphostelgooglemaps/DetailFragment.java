package com.example.viethoang.apphostelgooglemaps;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DetailFragment extends Fragment{

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        placeArrayList = new ArrayList<Place>();


    }

    private ArrayList<Place> placeArrayListPost = null;

    ArrayList<Place> placeArrayList;
    PlaceAdapter adapter;
    ListView lvPlace;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragment_detail, container, false);

        lvPlace = (ListView) view.findViewById(R.id.lvInfo);
        lvPlace.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getActivity(), "key: "+position, Toast.LENGTH_SHORT).show();
            }
        });

        Query post = FirebaseDatabase.getInstance().getReference("Place");
        post.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                placeArrayListPost = new ArrayList<>();
                for(DataSnapshot item : dataSnapshot.getChildren())
                {
                    Place place = item.getValue(Place.class);
                    placeArrayListPost.add(place);
                }

                if(placeArrayListPost!=null)
                {
                    for(int i = 0; i < placeArrayListPost.size(); i++)
                    {
                        try {
                            String id_place = placeArrayListPost.get(i).getId_place().toString().trim();
                            String lnglat = placeArrayListPost.get(i).getLnglat().toString().trim();
                            String title_hinh = ""+placeArrayListPost.get(i).getTitle().trim();
                            String name = placeArrayListPost.get(i).getUsername().toString().trim();
                            String diaChi = placeArrayListPost.get(i).getDiaChi().toString().trim();
                            String gia = "Giá: "+placeArrayListPost.get(i).getGiaPhong().toString().trim();
                            String dienTich = "Diện tích: "+placeArrayListPost.get(i).getDienTich().toString().trim();
                            String dienThoai = placeArrayListPost.get(i).getDienThoai().toString().trim();
                            String info = placeArrayListPost.get(i).getInfo().toString().trim();
                            String dateTime = placeArrayListPost.get(i).getNgayThang().toString().trim();


                            placeArrayList.add(new Place(id_place,name,"",diaChi,gia,dienTich,dienThoai,info,title_hinh,dateTime));


                        }
                        catch (NullPointerException e)
                        {
                            Toast.makeText(getActivity(), "Có lỗi xảy ra", Toast.LENGTH_SHORT).show();
                        }

                    }

                    adapter = new PlaceAdapter(getActivity(),R.layout.row_place,placeArrayList);


                    lvPlace.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getActivity(), "Có lỗi xảy ra", Toast.LENGTH_SHORT).show();
            }
        });

//        placeArrayList = new ArrayList<Place>();
//        placeArrayList.add(new Place("","le viet hoang","abckuuehf","Da nang","Giá: 1200000","Rộng: 25m","","","https://firebasestorage.googleapis.com/v0/b/hostel-a2982.appspot.com/o/Place%2F94895a21-c263-4fbd-b923-d23f28457875?alt=media&token=ea75cb94-6c4b-4d3f-9026-17a82ccf53b1"));
//        placeArrayList.add(new Place("","le viet hoang","abckuuehf","Da nang","Giá: 1200000","Rộng: 25m","","","https://firebasestorage.googleapis.com/v0/b/hostel-a2982.appspot.com/o/Place%2F94895a21-c263-4fbd-b923-d23f28457875?alt=media&token=ea75cb94-6c4b-4d3f-9026-17a82ccf53b1"));




        return view;
    }

}
