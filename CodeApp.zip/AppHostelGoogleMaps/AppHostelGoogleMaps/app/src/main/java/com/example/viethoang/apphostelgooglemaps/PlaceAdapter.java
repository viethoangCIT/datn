package com.example.viethoang.apphostelgooglemaps;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class PlaceAdapter extends BaseAdapter {

    private Context context;
    private int layout;
    private List<Place> placeList;

    public PlaceAdapter(Context context, int layout, List<Place> placeList) {
        this.context = context;
        this.layout = layout;
        this.placeList = placeList;
    }

    @Override
    public int getCount() {

        return placeList.size();

    }

    @Override
    public Object getItem(int position) {
        return placeList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class viewHolder
    {
        CircleImageView imgAvatar;
        ImageView imgHinhAnh;

        TextView txtUsername, txtGiaPhong, txtDienTich, txtDiaChi, txtNgayThang;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        viewHolder holder;
        if(convertView==null)
        {
            holder = new viewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(layout,null);

            holder.txtUsername = (TextView) convertView.findViewById(R.id.txtUsername);
            holder.txtNgayThang = (TextView) convertView.findViewById(R.id.txtNgayThang);
            holder.txtGiaPhong = (TextView) convertView.findViewById(R.id.txtGiaPhong);
            holder.txtDienTich = (TextView) convertView.findViewById(R.id.txtDienTich);
            holder.txtDiaChi = (TextView) convertView.findViewById(R.id.txtDiaChi);
            holder.imgHinhAnh = (ImageView)convertView.findViewById(R.id.imgHinhAnh);

            convertView.setTag(holder);
        }else{
            holder = (viewHolder) convertView.getTag();
        }

        final Place place = placeList.get(position);
        holder.txtUsername.setText(place.getUsername());
        holder.txtGiaPhong.setText(place.getGiaPhong());
        holder.txtDienTich.setText(place.getDienTich());
        holder.txtUsername.setText(place.getUsername());
        holder.txtDiaChi.setText(place.getDiaChi());
        holder.txtNgayThang.setText(place.getNgayThang());

        Picasso.with(context).load(place.getTitle()).into(holder.imgHinhAnh);

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDetail(place.getId_place());
            }
        });

        return convertView;
    }

    private void openDetail(String...details)
    {
        Intent intent = new Intent(context, Detail.class);
        Bundle bundle = new Bundle();
        bundle.putString("id_place",details[0]);
        intent.putExtras(bundle);
        context.startActivity(intent);

//        Intent intent = new Intent(context, Detail.class);
//        intent.putExtra("Id Key",details[0]);
//        context.startActivity(intent);
    }

}
